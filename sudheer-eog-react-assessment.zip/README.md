## Create React App Visualization

Read more about this assessment here
