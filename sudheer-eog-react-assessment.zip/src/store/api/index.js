import findLocationByLatLng from "./findLocationByLatLng";
import findWeatherbyId from "./findWeatherById";
import getDrone from "./getDrone";

export default {
  findLocationByLatLng,
  findWeatherbyId,
  getDrone
};
